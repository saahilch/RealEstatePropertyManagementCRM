package com.app.controller;

import com.app.entities.User;
import com.app.repositiory.UserRepository;
import com.app.securityconfig.JwtUtil;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController // Marks this class as a REST controller, capable of handling HTTP requests and returning JSON responses.
@RequestMapping("/auth") // Specifies the base URL for all endpoints in this controller.
public class AuthController {

    // Dependency injections for UserRepository, PasswordEncoder, AuthenticationManager, and JwtUtil.
    private final UserRepository userRepository; // Used for interacting with the database to manage user data.
    private final PasswordEncoder passwordEncoder; // For encrypting user passwords before storing them in the database.
    private final AuthenticationManager authenticationManager; // Used for handling user authentication logic.
    private final JwtUtil jwtUtil; // Utility class for generating and validating JWT tokens.

    // Constructor-based dependency injection for the required beans.
    public AuthController(UserRepository userRepository, PasswordEncoder passwordEncoder, AuthenticationManager authenticationManager, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
    }

    /**
     * Endpoint to register a new user.
     * URL: POST /auth/register
     * @param user The user object sent in the request body.
     * @return A success message indicating the user was registered.
     */
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        // Encrypt the user's password before saving it to the database.
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        // Save the user entity to the database using the UserRepository.
        userRepository.save(user);
        // Return a success response.
        return ResponseEntity.ok("User registered successfully");
    }

    /**
     * Endpoint to authenticate a user and provide a JWT token.
     * URL: POST /auth/login
     * @param user The user object containing email and password for authentication.
     * @return A JWT token if authentication is successful.
     */
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody User user) {
        // Authenticate the user's email and password.
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword()));
        // Generate a JWT token for the authenticated user.
        String token = jwtUtil.generateToken(user.getEmail());
        // Return the generated token as the response.
        return ResponseEntity.ok(token);
    }
}
