package com.app.controller;

import com.app.entities.Properties;
import com.app.entities.User;
import com.app.services.PropertiesService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for handling operations related to properties.
 */
@RestController
@RequestMapping("/properties") // Base URL for property-related endpoints.
public class PropertiesController {

    private final PropertiesService propertiesService;

    /**
     * Constructor to initialize the properties service.
     * @param propertiesService The service for managing property operations.
     */
    public PropertiesController(PropertiesService propertiesService) {
        this.propertiesService = propertiesService;
    }

    /**
     * Adds a new property.
     * URL: POST /properties
     * @param property The property details from the request body.
     * @param manager The manager (authenticated user) adding the property.
     * @return The newly added property with the manager assigned.
     */
    @PostMapping
    public ResponseEntity<Properties> addProperty(@RequestBody Properties property,
                                                  @RequestAttribute("user") User manager) {
        property.setManager(manager); // Assign the authenticated user as the manager.
        return ResponseEntity.ok(propertiesService.addProperty(property));
    }

    /**
     * Updates an existing property by ID.
     * URL: PUT /properties/{id}
     * @param id The ID of the property to update.
     * @param property The updated property details from the request body.
     * @return The updated property object.
     */
    @PutMapping("/{id}")
    public ResponseEntity<Properties> updateProperty(@PathVariable Long id, @RequestBody Properties property) {
        return ResponseEntity.ok(propertiesService.updateProperty(id, property));
    }

    /**
     * Deletes a property by ID.
     * URL: DELETE /properties/{id}
     * @param id The ID of the property to delete.
     * @return A 204 No Content response if the property was successfully deleted.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProperty(@PathVariable Long id) {
        propertiesService.deleteProperty(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * Retrieves a property by ID.
     * URL: GET /properties/{id}
     * @param id The ID of the property to retrieve.
     * @return The property details if found.
     */
    @GetMapping("/{id}")
    public ResponseEntity<Properties> getPropertyById(@PathVariable Long id) {
        return ResponseEntity.ok(propertiesService.getPropertyById(id));
    }

    /**
     * Retrieves all properties.
     * URL: GET /properties
     * @return A list of all properties.
     */
    @GetMapping
    public ResponseEntity<List<Properties>> getAllProperties() {
        return ResponseEntity.ok(propertiesService.getAllProperties());
    }

    /**
     * Retrieves all properties managed by a specific manager.
     * URL: GET /properties/manager/{managerId}
     * @param managerId The ID of the manager whose properties to retrieve.
     * @return A list of properties managed by the specified manager.
     */
    @GetMapping("/manager/{managerId}")
    public ResponseEntity<List<Properties>> getPropertiesByManager(@PathVariable Long managerId) {
        return ResponseEntity.ok(propertiesService.getPropertiesByManager(managerId));
    }
}
